public class SortingTester {
    public static boolean checkSort(ISort sorter, int size) {
        // TODO: implement this
        return false;
    }

    public static boolean isStable(ISort sorter, int size) {
        // TODO: implement this
        return false;
    }

    public static void main(String[] args) {
        // TODO: implement this
    }
}
